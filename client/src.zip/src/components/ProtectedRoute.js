import React from "react";
import { useSelector } from "react-redux";
import { Navigate } from "react-router-dom";
import { RouteLogin } from "../helper/RouteName";

const ProtectedRoute = ({ children }) => {
  const isAuthenticated = useSelector((state) => state.auth.isAuthenticated);
  console.log("✅ ProtectedRoute isAuthenticated:", isAuthenticated);

  // If not authenticated, redirect
  if (!isAuthenticated) {
    return <Navigate to={RouteLogin} replace />;
  }

  // Else, render the protected component
  return children;
};

export default ProtectedRoute;
