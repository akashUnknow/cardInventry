import React from 'react'

const Index = () => {
  return (
    <div>
      index
index
    </div>
  )
}

export default Index