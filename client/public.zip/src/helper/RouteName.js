export const RouteIndex = '/'
// helper/RouteName.js
export const Routecardinventry = '/card-inventry' 
export const RouteAddInventory= '/AddInventory'
export const RoutePersoCard= '/PersoCard'
